# Troubleshooting Rápido
(…dicas conforme acima)