-- supabase_schema.sql
(…SQL completo conforme acima na conversa)